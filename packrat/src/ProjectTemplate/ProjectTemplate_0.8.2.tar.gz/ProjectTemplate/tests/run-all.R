library(testthat)

test_check("ProjectTemplate")
