list_store$insert(iter, position)
list_store$set(iter, ...)
