toplevel <- widget$getToplevel()
if (toplevel$flags() & GtkWidgetFlags["toplevel"])
{
  # Perform action on toplevel.
}
