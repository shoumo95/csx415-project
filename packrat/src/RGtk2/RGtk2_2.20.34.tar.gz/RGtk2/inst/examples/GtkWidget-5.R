window$realize()
window$window$setBackPixmap(NULL, FALSE)
window$show()
