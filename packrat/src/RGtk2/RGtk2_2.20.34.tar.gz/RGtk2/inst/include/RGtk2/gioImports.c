#ifndef S_GIO_IMPORTS_C
#define S_GIO_IMPORTS_C
#include <RGtk2/gio.h>

#include <RGtk2/gobjectImports.c>

#include <RGtk2/gioUserFuncImports.c>

#include <RGtk2/gioClassImports.c>

#endif
