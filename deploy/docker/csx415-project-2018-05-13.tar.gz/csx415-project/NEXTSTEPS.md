# NEXT STEPS

* We will look into optimizing the linear model by adjusting the family parameter in `glm()` function based on further examining the distribution of the Credit Limit data
* We will build a Logistic Regression (linear classification) model and see if that performs better compared to a liner regression model
* We will build a Random Forest model with Cross Validation to see if we can come up with a better model