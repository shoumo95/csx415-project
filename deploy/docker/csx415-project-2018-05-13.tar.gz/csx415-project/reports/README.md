# Model Reports

* Formal Problem Statemet (FPS.Rmd)
* Exploratory Data Analysis (EDA.Rmd)
* Feature Selection (feature-selection.Rmd)
* Model Training and Validation
* Model Performance and Tuning
* Project Performance