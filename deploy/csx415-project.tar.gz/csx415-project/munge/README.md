# Pre-Processing Data

* Bring new features in and cleanup NA values by assigning means (01-AddFeatures.R)
* Split the dataset to Training and Test sets (02-PrepareDataSets.R)