# Model Reports

* Formal Problem Statemet
* Exploratory Data Analysis
* Feature Selection
  + First Regression Model (linear)
  + First Classification Model (rpart)
* Model Training and Validation
  + Incorporation of an additional data set
* Model Performance and Tuning
* Project Performance
