# Model Markdowns

* Formal Problem Statemet (FPS)
* Exploratory Data Analysis (EDA)
* Feature Selection
  + First Regression Model (linear)
  + First Classification Model (rpart)
* Model Training and Validation
  + Incorporation of additional data
* Project Performance
